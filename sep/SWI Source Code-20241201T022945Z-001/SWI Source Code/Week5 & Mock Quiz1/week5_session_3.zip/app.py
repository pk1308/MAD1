from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from models import db, User, Role, Association

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///myapp.sqlite3"

db.init_app(app)

app.app_context().push()

# =============== Controllers for Role Model First =================

# Read Role
@app.route('/') # default get method
def all_roles():
    roles = Role.query.all() # list of objects [<Role 1>, <Role 2>.. etc.]
    print(roles)
    return render_template('index.html', roles = roles)

# Create Role
@app.route('/create_role', methods=['GET', 'POST'])
def create_role():
    if request.method == 'POST':
        role = request.form.get('role')
        new_role = Role(role_name = role)
        db.session.add(new_role)
        db.session.commit()
        return redirect('/')
    return render_template('create_role.html')

# Update Role
# /update_role
# /update_role/<id> Dynamic
@app.route('/update_role/<int:id>', methods=['GET', 'POST'])
def edit_role(id):
    this_role = Role.query.get(id) # retireve a particular object from the database
    if request.method == 'POST':
        role = request.form.get('role')
        this_role.role_name = role # update
        db.session.commit()
        return redirect('/')
    return render_template('update_role.html', this_role = this_role)

# Delete Role
@app.route('/delete_role/<int:id>')
def del_role(id):
    this_role = Role.query.get(id)
    db.session.delete(this_role)
    db.session.commit()
    return redirect('/')

# Retrieve userd for a particular role
# /users/<role> pattern
# /users/TA 
# /users/Adminitrator
@app.route('/users/<role>') #e.g /users/mentor
def get_users(role):
    role_obj = Role.query.filter_by(role_name = role).first()
    users = role_obj.users # role is object, users = [list of objects]
    return render_template('role_users.html', users = users, role = role)

app.run(debug = True)