from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///onemany.sqlite3"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///manymany.sqlite3"

db = SQLAlchemy(app)

app.app_context().push()

# ===== models for one-to-many relationship ======
# child table 
# class User(db.Model):
#     id = db.Column(db.Integer, primary_key = True)
#     username = db.Column(db.String(20), nullable = False, unique = True)
#     password = db.Column(db.String(), nullable = False)
#     role_id = db.Column(db.Integer, db.ForeignKey('role.id'), nullable = False)

#create another element role, --> id, role_name 
# Parent table
# class Role(db.Model):
#     id = db.Column(db.Integer, primary_key = True)
#     role_name = db.Column(db.String(), nullable = False, unique = True)
#     users = db.Relationship('User', backref = 'role')


# Class - Role ===> table - role
# # "/" - base url - http://127.0.0.1:5000
# @app.route('/')
# def my_func():ei
#     print("I am triggered")
#     return render_template("index.html")


# # "/hello"  http://127.0.0.1:5000/hello
# @app.route("/hello")
# def my_func_2():
#     return "hello users from flask"

# app.run()

# my_dict["my_key"] = "value"


# username = request.form.get("username") or null # backend validation

# ===== models for many-to-many relationship ======
class User(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    username = db.Column(db.String(20), nullable = False, unique = True)
    password = db.Column(db.String(), nullable = False)
    roles = db.relationship('Role', backref = 'users', secondary = 'association')

class Role(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    role_name = db.Column(db.String(), nullable = False, unique = True)
    
class Association(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable = False)
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), nullable = False)



# Controller:

# 1. return render_template('html.name', data)
# 2. return redirect('/home')


# API:

# {
#     "param_1": "value_1"
#     "param_2": "value_2"
# }